<?php

return array(
    'default_controller'    => 'home', // controller mặc định
    'default_action'        => 'index', // action mặc định
    '404_controller'        => 'error', // controller lỗi 404
    '404_action'            => 'index'  // action lỗi 404
);
?>
