<?php
    if (!defined('PATH_SYSTEM')) {
        die ('Bad requested!');
    }
    return array(
        'csrf_token_name'       => 'tokenname',
        'base_url'              => 'http://localhost/mvc'
    );
?>
