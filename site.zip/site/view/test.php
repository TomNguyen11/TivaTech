<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Test</title>
  </head>
  <body>
    <?php
     echo $result;
     echo "<br/>".$query;
    ?>
  </body>
</html>
